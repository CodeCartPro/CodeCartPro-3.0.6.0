<?php
// Heading
$_['heading_title']  = 'Reset your password';

// Text
$_['text_password']  = 'Enter the new password you wish to use.';
$_['text_success']   = 'Success: Your password has been successfully updated.';

// Entry
$_['entry_password'] = 'Password';
$_['entry_confirm']  = 'Confirm';

// Error
$_['error_password'] = 'Password must be between 10 and 40 characters!';
$_['error_confirm']  = 'Password and password confirmation do not match!';
$_['text_show_password'] = 'Show / hide password';
