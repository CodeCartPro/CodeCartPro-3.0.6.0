<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']          = 'Information';

// Text
$_['text_success']           = 'Success: You have modified information!';
$_['text_list']              = 'Information List';
$_['text_add']               = 'Add Information';
$_['text_edit']              = 'Edit Information';
$_['text_default']           = 'Default';
$_['text_keyword']           = 'Do not use spaces, instead replace spaces with - and make sure the SEO URL is globally unique.';

// Column
$_['column_title']           = 'Information Title';
$_['column_sort_order']      = 'Sort Order';
$_['column_noindex']         = 'Index';
$_['column_action']          = 'Action';

// Entry
$_['entry_title']            = 'Information Title';
$_['entry_meta_h1']       	 = 'Meta Tag H1';
$_['entry_description']      = 'Description';
$_['entry_meta_title']       = 'Meta Tag Title';
$_['entry_meta_keyword']     = 'Meta Tag Keywords';
$_['entry_meta_description'] = 'Meta Tag Description';
$_['entry_store']            = 'Stores';
$_['entry_keyword']          = 'Keyword';
$_['entry_bottom']           = 'Bottom';
$_['entry_status']           = 'Status';
$_['entry_sort_order']       = 'Sort Order';
$_['entry_layout']           = 'Layout Override';
$_['entry_noindex']          = 'Index';

// Help
$_['help_bottom']            = 'Display in the bottom footer.';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify information!';
$_['error_title']            = 'Information Title must be between 1 and 64 characters!';
$_['error_description']      = 'Description must be more than 3 characters!';
$_['error_meta_title']       = 'Meta Title must be greater than 1 and less than 255 characters!';
$_['error_keyword']          = 'SEO URL already in use!';
$_['error_unique']           = 'SEO URL must be unique!';
$_['error_account']          = 'Warning: This information page cannot be deleted as it is currently assigned as the store account terms!';
$_['error_checkout']         = 'Warning: This information page cannot be deleted as it is currently assigned as the store checkout terms!';
$_['error_affiliate']        = 'Warning: This information page cannot be deleted as it is currently assigned as the store affiliate terms!';
$_['error_return']           = 'Warning: This information page cannot be deleted as it is currently assigned as the store return terms!';
$_['error_store']            = 'Warning: This information page cannot be deleted as it is currently used by %s stores!';
$_['button_generate_seo_url'] = 'Generate SEO URL';
$_['error_meta_h1'] = 'HTML Tag H1 must be greater than 0 and less than 255 characters!';
