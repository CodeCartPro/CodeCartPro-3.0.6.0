<?php
// CodeCart PRO ru-ru language pack. Missing keys fall back to en-gb.
$_['heading_title'] = 'Отзывы';
$_['text_success'] = 'Настройки успешно изменены!';
$_['text_list'] = 'Список отзывов';
$_['text_add'] = 'Добавить';
$_['text_edit'] = 'Редактирование';
$_['text_filter'] = 'Фильтр';
$_['column_product'] = 'Товар';
$_['column_author'] = 'Автор';
$_['column_rating'] = 'Рейтинг';
$_['column_status'] = 'Статус';
$_['column_date_added'] = 'Дата добавления';
$_['column_action'] = 'Действие';
$_['entry_product'] = 'Товар';
$_['entry_author'] = 'Автор';
$_['entry_rating'] = 'Рейтинг';
$_['entry_status'] = 'Статус';
$_['entry_text'] = 'Текст';
$_['entry_date_added'] = 'Дата добавления';
$_['help_product'] = '(Автозаполнение)';
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';
$_['error_product'] = 'Требуется выбрать товар!';
$_['error_author'] = 'Имя автора должно содержать от 3 до 64 символов!';
$_['error_text'] = 'Текст отзыва должен содержать хотя бы 1 символ!';
$_['error_rating'] = 'Требуется установить рейтинг!';
