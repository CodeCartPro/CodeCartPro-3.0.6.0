<?php
// CodeCart PRO ru-ru language pack. Missing keys fall back to en-gb.
$_['heading_title'] = 'Последняя активность';
$_['text_extension'] = 'Расширения';
$_['text_success'] = 'Настройки успешно изменены!';
$_['text_edit'] = 'Редактирование';
$_['text_activity_register'] = '<a href="customer_id=%d">%s</a> - регистрация аккаунта.';
$_['text_activity_edit'] = '<a href="customer_id=%d">%s</a> - обновлена информация аккаунта.';
$_['text_activity_password'] = '<a href="customer_id=%d">%s</a> - обновлен пароль.';
$_['text_activity_reset'] = '<a href="customer_id=%d">%s</a> - сброшен пароль учетной записи.';
$_['text_activity_login'] = '<a href="customer_id=%d">%s</a> - выполнен вход.';
$_['text_activity_forgotten'] = '<a href="customer_id=%d">%s</a> - запрос нового пароля.';
$_['text_activity_address_add'] = '<a href="customer_id=%d">%s</a> - добавлен новый адрес.';
$_['text_activity_address_edit'] = '<a href="customer_id=%d">%s</a> - обновлен адрес.';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a> - удален один из адресов.';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a> отправил запрос на <a href="return_id=%d">возврат</a> товара.';
$_['text_activity_return_guest'] = '%s отправил запрос на <a href="return_id=%d">возврат</a> товара.';
$_['text_activity_order_account'] = '<a href="customer_id=%d">%s</a> <a href="order_id=%d"> - создан новый заказ</a>.';
$_['text_activity_order_guest'] = '%s <a href="order_id=%d"> - создан  новый заказ</a>.';
$_['text_activity_affiliate_add'] = '<a href="customer_id=%d">%s</a> зарегистрировал партнёрскую учётную запись.';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a> - зарегистрирован новый аккаунт.';
$_['text_activity_transaction'] = '<a href="customer_id=%d">%s</a> - получена комиссия за <a href="order_id=%d">заказ</a>.';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';
$_['entry_width'] = 'Ширина';
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';
